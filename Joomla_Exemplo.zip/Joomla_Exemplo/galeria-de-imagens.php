<?php
defined('JPATH_BASE') or die;
JHtml::stylesheet(JUri::base() . '/templates/protostar/css/lightgallery.min.css');
JHtml::script(JUri::base() . '/templates/protostar/js/jquery-3.5.1.min.js');
JHtml::script(JUri::base() . '/templates/protostar/js/lightgallery-all.min.js');
?>


<?php

$galeria = json_decode($this->item->jcfields[4]->rawvalue, true);
	if (empty($galeria))
	{
		return;
	}


	else{
	?>
	<div class="row">
		<div class="col-md-12">
			<div id="lightgallery">
				<?php
					foreach ($galeria as $foto)
					{
				?>
						<a class="grid-item" href="<?php echo $foto["imagem"]; ?>" >
							<img src="<?php echo $foto["imagem"]; ?>" alt="<?php echo $foto["alt"]; ?>" />
						</a>
				<?php		
					}
				?>
			</div>
			<script>

				//var galeria = jQuery.noConflict();

				$(document).ready(function() {
					$("#lightgallery").lightGallery(); 
				});

			</script>
		</div>
	</div>
	<?php	
	}
	?>